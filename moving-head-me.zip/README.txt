A Pen created at CodePen.io. You can find this one at https://codepen.io/maaarj/pen/vmYPqm.

 A tribute to my new look. I put on bangs. hehe. made with scss and html :)
anyways, hope you enjoy.